<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Refferal extends Model
{
    protected $fillable = ['refferal'];
}
